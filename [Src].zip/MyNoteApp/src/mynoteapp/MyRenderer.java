/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mynoteapp;

import java.awt.Component;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author Computer
 */
public class MyRenderer extends DefaultTableCellRenderer {

    public Component getTableCellRendererComponent(JTable table, ImageIcon icon) {
        setIcon(icon);
        return this;
    }
}
