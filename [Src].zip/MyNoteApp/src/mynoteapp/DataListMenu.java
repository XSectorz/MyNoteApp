/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mynoteapp;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author Computer
 */
public class DataListMenu extends javax.swing.JFrame {

    private DefaultTableCellRenderer cellRenderer;
    private DefaultTableCellRenderer cellRendererInfo;
    private DefaultTableCellRenderer cellRendererName;
    
    public DataListMenu() {
        initComponents();
        this.setResizable(false);
        this.setVisible(true);
        this.getContentPane().setBackground(new Color(204, 204, 204));
        setTitle("MyNote - Java Project");
        cellRenderer = new TableCellRenderer();
        cellRendererName = new TableCellRendererInfo();
        cellRendererInfo = new TableCellRendererInfo();
        cellRenderer.setHorizontalAlignment(JLabel.CENTER);
        cellRendererName.setHorizontalAlignment(JLabel.CENTER);
        DataTable.getColumnModel().getColumn(0).setPreferredWidth(5);
        DataTable.getColumnModel().getColumn(1).setPreferredWidth(50);
        DataTable.getColumnModel().getColumn(4).setPreferredWidth(20);
        DataTable.getColumnModel().getColumn(5).setPreferredWidth(20);
        DataTable.getColumnModel().getColumn(6).setPreferredWidth(20);
        Delete_Button2.setBackground(new Color(204, 204, 204));
        Delete_Button2.setFocusable(false);
        Delete_Button2.setContentAreaFilled(false);
        Delete_Button2.setFocusPainted(false);
        BackHome_Button.setBackground(new Color(204, 204, 204));
        BackHome_Button.setFocusable(false);
        BackHome_Button.setContentAreaFilled(false);
        BackHome_Button.setFocusPainted(false);
        Icon_1.setText("\u2714");
        Icon_2.setText("\u2716");
        Icon_3.setText("\u263a");

        Count_NoN.setText("" + Main.Count_NotEnd);
        Count_NoN2.setText("" + Main.Count_End);
        Count_NoN3.setText("" + Main.Count_Progress);

        for (int i = 0; i < 7; i++) {
            if (i == 3) {
                DataTable.getColumnModel().getColumn(i).setCellRenderer(cellRendererInfo);
                continue;
            } else if (i==2) {
                DataTable.getColumnModel().getColumn(i).setCellRenderer(cellRendererName);
                continue;          
            }
            DataTable.getColumnModel().getColumn(i).setCellRenderer(cellRenderer);
        }
        DataTable.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);

    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        DataTable = new javax.swing.JTable();
        PanelControl = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        Icon_1 = new javax.swing.JLabel();
        Text_Count = new javax.swing.JLabel();
        Count_NoN = new javax.swing.JLabel();
        Text_Count2 = new javax.swing.JLabel();
        Icon_2 = new javax.swing.JLabel();
        Text_Count3 = new javax.swing.JLabel();
        Count_NoN2 = new javax.swing.JLabel();
        Text_Count4 = new javax.swing.JLabel();
        Icon_3 = new javax.swing.JLabel();
        Text_Count5 = new javax.swing.JLabel();
        Count_NoN3 = new javax.swing.JLabel();
        Text_Count6 = new javax.swing.JLabel();
        DeletePanel = new javax.swing.JPanel();
        Delete_Button2 = new javax.swing.JButton();
        BackHome_Button = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(102, 102, 255));

        DataTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "สถานะ", "กิจกรรม", "รายละเอียด", "มีวันหมดอายุ", "วันที่เริ่ม", "วันที่จบ"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        DataTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(DataTable);
        if (DataTable.getColumnModel().getColumnCount() > 0) {
            DataTable.getColumnModel().getColumn(0).setMinWidth(35);
            DataTable.getColumnModel().getColumn(0).setMaxWidth(35);
            DataTable.getColumnModel().getColumn(1).setMinWidth(70);
            DataTable.getColumnModel().getColumn(1).setPreferredWidth(70);
            DataTable.getColumnModel().getColumn(1).setMaxWidth(70);
            DataTable.getColumnModel().getColumn(2).setMinWidth(120);
            DataTable.getColumnModel().getColumn(2).setPreferredWidth(120);
            DataTable.getColumnModel().getColumn(2).setMaxWidth(120);
            DataTable.getColumnModel().getColumn(4).setMinWidth(90);
            DataTable.getColumnModel().getColumn(4).setPreferredWidth(90);
            DataTable.getColumnModel().getColumn(4).setMaxWidth(90);
            DataTable.getColumnModel().getColumn(5).setMinWidth(90);
            DataTable.getColumnModel().getColumn(5).setPreferredWidth(90);
            DataTable.getColumnModel().getColumn(5).setMaxWidth(90);
            DataTable.getColumnModel().getColumn(6).setMinWidth(90);
            DataTable.getColumnModel().getColumn(6).setPreferredWidth(90);
            DataTable.getColumnModel().getColumn(6).setMaxWidth(90);
        }

        PanelControl.setBackground(new java.awt.Color(204, 204, 204));
        PanelControl.setForeground(new java.awt.Color(255, 102, 0));
        PanelControl.setFocusable(false);

        jPanel1.setBackground(new java.awt.Color(190, 190, 190));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setFont(new java.awt.Font("TH SarabunPSK", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("ข้อมูลเบื้องต้น");

        Icon_1.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        Icon_1.setForeground(new java.awt.Color(51, 255, 0));
        Icon_1.setText("{1}");

        Text_Count.setFont(new java.awt.Font("TH SarabunPSK", 0, 24)); // NOI18N
        Text_Count.setText("(กิจกรรมเสร็จสิ้น) :");

        Count_NoN.setFont(new java.awt.Font("TH SarabunPSK", 1, 36)); // NOI18N
        Count_NoN.setForeground(new java.awt.Color(0, 255, 0));
        Count_NoN.setText("{2}");
        Count_NoN.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));

        Text_Count2.setFont(new java.awt.Font("TH SarabunPSK", 0, 24)); // NOI18N
        Text_Count2.setText("รายการ");

        Icon_2.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        Icon_2.setForeground(new java.awt.Color(255, 51, 51));
        Icon_2.setText("{3}");

        Text_Count3.setFont(new java.awt.Font("TH SarabunPSK", 0, 24)); // NOI18N
        Text_Count3.setText("(กิจกรรมที่ผ่านมาเเล้ว) :");

        Count_NoN2.setFont(new java.awt.Font("TH SarabunPSK", 1, 36)); // NOI18N
        Count_NoN2.setForeground(new java.awt.Color(255, 51, 51));
        Count_NoN2.setText("{4}");
        Count_NoN2.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));

        Text_Count4.setFont(new java.awt.Font("TH SarabunPSK", 0, 24)); // NOI18N
        Text_Count4.setText("รายการ");

        Icon_3.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        Icon_3.setForeground(new java.awt.Color(255, 255, 51));
        Icon_3.setText("{5}");

        Text_Count5.setFont(new java.awt.Font("TH SarabunPSK", 0, 24)); // NOI18N
        Text_Count5.setText("(กิจกรรมกำลังดำเนิน) :");

        Count_NoN3.setFont(new java.awt.Font("TH SarabunPSK", 1, 36)); // NOI18N
        Count_NoN3.setForeground(new java.awt.Color(255, 255, 51));
        Count_NoN3.setText("{6}");
        Count_NoN3.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));

        Text_Count6.setFont(new java.awt.Font("TH SarabunPSK", 0, 24)); // NOI18N
        Text_Count6.setText("รายการ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(118, 118, 118)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(Icon_3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Text_Count5)
                                .addGap(18, 18, 18)
                                .addComponent(Count_NoN3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Text_Count6))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(Icon_2)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(Text_Count3)
                                    .addGap(18, 18, Short.MAX_VALUE)
                                    .addComponent(Count_NoN2)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(Text_Count4))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(Icon_1)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(Text_Count)
                                    .addGap(18, 18, 18)
                                    .addComponent(Count_NoN)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(Text_Count2))))))
                .addContainerGap(38, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Icon_1)
                    .addComponent(Text_Count)
                    .addComponent(Count_NoN)
                    .addComponent(Text_Count2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Icon_2)
                    .addComponent(Text_Count3)
                    .addComponent(Count_NoN2)
                    .addComponent(Text_Count4))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Count_NoN3)
                    .addComponent(Text_Count5)
                    .addComponent(Icon_3)
                    .addComponent(Text_Count6))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        DeletePanel.setBackground(new java.awt.Color(190, 190, 190));
        DeletePanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        Delete_Button2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/DeleteAll2.png"))); // NOI18N
        Delete_Button2.setBorder(null);
        Delete_Button2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Delete_Button2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Delete_Button2MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout DeletePanelLayout = new javax.swing.GroupLayout(DeletePanel);
        DeletePanel.setLayout(DeletePanelLayout);
        DeletePanelLayout.setHorizontalGroup(
            DeletePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DeletePanelLayout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addComponent(Delete_Button2, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(75, Short.MAX_VALUE))
        );
        DeletePanelLayout.setVerticalGroup(
            DeletePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DeletePanelLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(Delete_Button2)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        BackHome_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/BackButton_1.png"))); // NOI18N
        BackHome_Button.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        BackHome_Button.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BackHome_Button.setMaximumSize(new java.awt.Dimension(90, 90));
        BackHome_Button.setMinimumSize(new java.awt.Dimension(90, 90));
        BackHome_Button.setPreferredSize(new java.awt.Dimension(90, 90));
        BackHome_Button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BackHome_ButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BackHome_ButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BackHome_ButtonMouseExited(evt);
            }
        });

        javax.swing.GroupLayout PanelControlLayout = new javax.swing.GroupLayout(PanelControl);
        PanelControl.setLayout(PanelControlLayout);
        PanelControlLayout.setHorizontalGroup(
            PanelControlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelControlLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(PanelControlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelControlLayout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(DeletePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(PanelControlLayout.createSequentialGroup()
                        .addGap(92, 92, 92)
                        .addComponent(BackHome_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(27, Short.MAX_VALUE))
        );
        PanelControlLayout.setVerticalGroup(
            PanelControlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelControlLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PanelControlLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelControlLayout.createSequentialGroup()
                        .addComponent(DeletePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)
                        .addComponent(BackHome_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(255, 153, 51));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 21, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelControl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 288, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(PanelControl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Delete_Button2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Delete_Button2MouseClicked
        int confirm = JOptionPane.showConfirmDialog(null, getMsg("ท่านยืนยันที่จะลบข้อมูลทั้งหมดหรือไม่"), "เเจ้งเตือน", JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE);
        if (confirm == JOptionPane.OK_OPTION) {
            //System.out.println("DELETE ALL");
            final File floder = new File("/MyNote/data");
            removeData(floder);
        }
    }//GEN-LAST:event_Delete_Button2MouseClicked

    private void BackHome_ButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BackHome_ButtonMouseClicked
        MainMenu menu = new MainMenu();
        menu.setLocationRelativeTo(null);
        this.setVisible(false);
    }//GEN-LAST:event_BackHome_ButtonMouseClicked

    private void BackHome_ButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BackHome_ButtonMouseEntered
        BackHome_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/BackButton_2.png")));
    }//GEN-LAST:event_BackHome_ButtonMouseEntered

    private void BackHome_ButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BackHome_ButtonMouseExited
         BackHome_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/BackButton_1.png")));
    }//GEN-LAST:event_BackHome_ButtonMouseExited
    private JLabel getMsg(String msg) {
        JLabel label = new JLabel(msg);
        label.setFont(new java.awt.Font("TH SarabunPSK", Font.BOLD, 18));

        return label;
    }

    public void removeData(final File floder) {
        for (final File fileEntry : floder.listFiles()) {
            if (fileEntry.getName().endsWith(".txt")) {
                try {
                    Files.deleteIfExists(Paths.get(fileEntry.getPath()));
                } catch(IOException e) {
                    JOptionPane.showMessageDialog(null, getMsg("เกิดข้อผิดพลาดกับข้อมูลระบบ"), "เเจ้งเตือน", JOptionPane.WARNING_MESSAGE);
                    e.printStackTrace();
                }
                
            }
        }
        MyNoteSystem.Note.clear();
        JOptionPane.showMessageDialog(null, getMsg("ทำการลบข้อมูลทั้งหมดเเล้ว"), "เเจ้งเตือน", JOptionPane.INFORMATION_MESSAGE);
        MainMenu main = new MainMenu();
        main.setLocationRelativeTo(null);
        this.setVisible(false);
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BackHome_Button;
    private javax.swing.JLabel Count_NoN;
    private javax.swing.JLabel Count_NoN2;
    private javax.swing.JLabel Count_NoN3;
    public static javax.swing.JTable DataTable;
    private javax.swing.JPanel DeletePanel;
    private javax.swing.JButton Delete_Button2;
    private javax.swing.JLabel Icon_1;
    private javax.swing.JLabel Icon_2;
    private javax.swing.JLabel Icon_3;
    private javax.swing.JPanel PanelControl;
    private javax.swing.JLabel Text_Count;
    private javax.swing.JLabel Text_Count2;
    private javax.swing.JLabel Text_Count3;
    private javax.swing.JLabel Text_Count4;
    private javax.swing.JLabel Text_Count5;
    private javax.swing.JLabel Text_Count6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
