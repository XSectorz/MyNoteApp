/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mynoteapp;

/**
 *
 * @author Computer
 */
public class MyNote {
    
    private String status;
    private boolean finish;
    private String name;
    private String description;
    private boolean expired;
    private String expiredIcon;
    private String start;
    private String end;
    
    public MyNote(String status,String name,String description,boolean expired,boolean finish,String start,String end,String expiredIcon){
        this.status = status;
        this.name = name;
        this.description = description;
        this.expired = expired;
        this.start = start;
        this.finish = finish;
        this.end = end;  
        this.expiredIcon = expiredIcon;
    }
    
    public MyNote() {
        this.status = "\u2716";
        this.name = "temp";
        this.description = "temp";
        this.expired = false;
        this.start = "0";
        this.end = "-";   
        this.expiredIcon = "\u2716";
        this.finish = false;
    }
    
    public String getNoteExpiredIcon() {
        return this.expiredIcon;
    }
    
    public void setNoteExpiredIcon(String expiredIcon) {
         this.expiredIcon = expiredIcon;
    }
    
    public boolean getNoteFinish() {
        return this.finish;
    }
    
    public void setNoteFinish(boolean finish) {
         this.finish = finish;
    }
    
    public boolean getNoteExpired() {
        return this.expired;
    }
    
    public void setNoteExpired(boolean expired) {
         this.expired = expired;
    }
    
    public String getNoteStatus() {
        return this.status;
    }
    
    public void setNoteStatus(String status) {
        this.status = status;
    }
    
    public String getNoteStart() {
        return this.start;
    }
    
    public void setNoteStart(String start) {
        this.start = start;
    }
    
    public String getNoteEnd() {
        return this.end;
    }
    
    public void setNoteEnd(String end) {
        this.end = end;
    }
    
    
    public String getNoteName() {
        return this.name;
    }
    
    public void setNoteName(String name) {
        this.name = name;
    }
    
    public String getNoteDescription() {
        return this.description;
    }
    
    public void setNoteDescription(String description) {
        this.description = description;
    }
}
