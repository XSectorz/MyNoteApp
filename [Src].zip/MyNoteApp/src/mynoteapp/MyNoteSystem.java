/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mynoteapp;

import java.util.ArrayList;

/**
 *
 * @author Computer
 */
public class MyNoteSystem {
    
    public static ArrayList<MyNote> Note = new ArrayList<>();
    
    public static MyNote getNote(String name) {
        
        for(MyNote note : Note) {
            if(note.getNoteName().equalsIgnoreCase(name)) {
                return note;
            }
        }
        
        return null;   
    }
}
