/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mynoteapp;

import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import static mynoteapp.MainMenu.delay;

/**
 *
 * @author Computer
 */
public class Main {

    public static int Count_NotEnd = 0;
    public static int Count_End = 0;
    public static int Count_Progress = 0;
    public static Timer timer = new Timer();
    public static int time = 0;

    public static DefaultComboBoxModel model;

    public static void main(String[] args) {
        String year[] = new String[5];
        for (int i = Calendar.getInstance().get(Calendar.YEAR); i < Calendar.getInstance().get(Calendar.YEAR) + 5; i++) {
            year[i - Calendar.getInstance().get(Calendar.YEAR)] = "" + i;
            //System.out.println("Current I: " + (i-Calendar.getInstance().get(Calendar.YEAR)) + " Value: " + i + " Year: " + Calendar.getInstance().get(Calendar.YEAR));
        }
        model = new DefaultComboBoxModel(year);

        MainMenu menu = new MainMenu();
        menu.setLocationRelativeTo(null);

        Main.timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                time+=1;
                MainMenu.getLabel().setIcon(new ImageIcon(getClass().getResource("/icon/Task_" + time + ".png")));
                if(time >= 4) {
                    time = 0;
                }
            }
        }, 0, delay);
    }
}
