/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mynoteapp;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontFormatException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Computer
 */
public class MainMenu extends javax.swing.JFrame {

    public static long delay = 1000L;

    public MainMenu() {
        initComponents();

        AddButton1.setFocusPainted(false);
        AddButton1.setBackground(new Color(240, 240, 240));
        AddButton1.setOpaque(true);
        AddButton1.setContentAreaFilled(false);
        SeeButton.setFocusPainted(false);
        SeeButton.setBackground(new Color(240, 240, 240));
        SeeButton.setOpaque(true);
        SeeButton.setContentAreaFilled(false);
        Manage_Button.setFocusPainted(false);
        Manage_Button.setBackground(new Color(240, 240, 240));
        Manage_Button.setOpaque(true);
        Manage_Button.setContentAreaFilled(false);
        Dev_Button.setFocusPainted(false);
        Dev_Button.setBackground(new Color(240, 240, 240));
        Dev_Button.setOpaque(true);
        Dev_Button.setContentAreaFilled(false);
        this.getContentPane().setBackground(new Color(190, 190, 190));
        this.setResizable(false);
        this.setVisible(true);

        setTitle("MyNote - Java Project");
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        SeeButton = new javax.swing.JButton();
        AddButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        Manage_Button = new javax.swing.JButton();
        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(34, 0), new java.awt.Dimension(34, 0), new java.awt.Dimension(34, 32767));
        Repeat = new javax.swing.JLabel();
        Dev_Button = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 0, 51));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setMinimumSize(new java.awt.Dimension(400, 410));
        setName("MainMenu"); // NOI18N
        setSize(new java.awt.Dimension(400, 410));

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        SeeButton.setFont(new java.awt.Font("TH SarabunPSK", 1, 18)); // NOI18N
        SeeButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/InfoButton_1.png"))); // NOI18N
        SeeButton.setBorder(null);
        SeeButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        SeeButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SeeButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                SeeButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                SeeButtonMouseExited(evt);
            }
        });
        SeeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SeeButtonActionPerformed(evt);
            }
        });

        AddButton1.setFont(new java.awt.Font("TH SarabunPSK", 1, 18)); // NOI18N
        AddButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/AddButton.png"))); // NOI18N
        AddButton1.setBorder(null);
        AddButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        AddButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AddButton1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                AddButton1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                AddButton1MouseExited(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/MyNoteIcon.png"))); // NOI18N

        Manage_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/ManageButton.png"))); // NOI18N
        Manage_Button.setBorder(null);
        Manage_Button.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Manage_Button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Manage_ButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Manage_ButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Manage_ButtonMouseExited(evt);
            }
        });

        Repeat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Task_1.png"))); // NOI18N

        Dev_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/DevButton_1.png"))); // NOI18N
        Dev_Button.setBorder(null);
        Dev_Button.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Dev_Button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Dev_ButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Dev_ButtonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Dev_ButtonMouseExited(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(154, 154, 154)
                        .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(83, 83, 83)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(SeeButton)
                            .addComponent(AddButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 317, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Manage_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Dev_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 315, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(105, 105, 105)
                        .addComponent(Repeat, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(74, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(AddButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(SeeButton)
                .addGap(18, 18, 18)
                .addComponent(filler1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Manage_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(Dev_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
                .addComponent(Repeat)
                .addGap(33, 33, 33))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AddButton1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddButton1MouseExited
        AddButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/AddButton.png")));
    }//GEN-LAST:event_AddButton1MouseExited

    private void AddButton1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddButton1MouseEntered
        AddButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/AddButton2.png")));
    }//GEN-LAST:event_AddButton1MouseEntered

    private void AddButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddButton1MouseClicked
        AddNoteMenu addMenu = new AddNoteMenu();
        addMenu.setLocation(this.getLocation());
        this.setVisible(false);
    }//GEN-LAST:event_AddButton1MouseClicked

    private void SeeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SeeButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SeeButtonActionPerformed

    private void SeeButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SeeButtonMouseExited
        SeeButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/InfoButton_1.png")));
    }//GEN-LAST:event_SeeButtonMouseExited

    private void SeeButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SeeButtonMouseEntered
        SeeButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/InfoButton_2.png")));
    }//GEN-LAST:event_SeeButtonMouseEntered

    private void SeeButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SeeButtonMouseClicked
        final File folder = new File("/MyNote/data");
        try {
            loadData(folder, "DataMenu");
        } catch (ParseException ex) {
            Logger.getLogger(MainMenu.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_SeeButtonMouseClicked

    private void Manage_ButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Manage_ButtonMouseEntered
        Manage_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/ManageButton_1.png")));
    }//GEN-LAST:event_Manage_ButtonMouseEntered

    private void Manage_ButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Manage_ButtonMouseExited
        Manage_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/ManageButton.png")));
    }//GEN-LAST:event_Manage_ButtonMouseExited

    private void Manage_ButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Manage_ButtonMouseClicked

        final File folder = new File("/MyNote/data");
        try {
            loadData(folder, "ManageMenu");
        } catch (ParseException ex) {
            Logger.getLogger(MainMenu.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_Manage_ButtonMouseClicked

    private void Dev_ButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Dev_ButtonMouseEntered
        Dev_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/DevButton_2.png")));
    }//GEN-LAST:event_Dev_ButtonMouseEntered

    private void Dev_ButtonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Dev_ButtonMouseExited
        Dev_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/DevButton_1.png")));
    }//GEN-LAST:event_Dev_ButtonMouseExited

    private void Dev_ButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Dev_ButtonMouseClicked
        InfoDevMenu dev = new InfoDevMenu();
        dev.setLocation(this.location());
        dev.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_Dev_ButtonMouseClicked

    public void loadData(final File floder, String type) throws ParseException {

        Main.Count_End = 0;
        Main.Count_NotEnd = 0;
        Main.Count_Progress = 0;
        MyNoteSystem.Note.clear();

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            for (final File fileEntry : floder.listFiles()) {
                if (fileEntry.getName().endsWith(".txt")) {
                    //System.out.println(fileEntry.getName());   
                    try {
                        //FileReader fr = new FileReader("/MyNote/data/" + fileEntry.getName());
                        //BufferedReader br = new BufferedReader(fr);
                        File data = new File("/MyNote/data/" + fileEntry.getName());
                        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(data), "UTF-8"));
                        String temp;
                        MyNote note = new MyNote();
                        while ((temp = br.readLine()) != null) {
                            if (temp.startsWith("Title: ")) {
                                note.setNoteName(temp.replace("Title: ", ""));
                            } else if (temp.startsWith("Description: ")) {
                                note.setNoteDescription(temp.replace("Description: ", ""));
                            } else if (temp.startsWith("Expired: ")) {
                                note.setNoteExpired(Boolean.valueOf(temp.replace("Expired: ", "")));
                            } else if (temp.startsWith("Start: ")) {
                                note.setNoteStart(temp.replace("Start: ", ""));
                            } else if (temp.startsWith("Finish: ")) {
                                note.setNoteFinish(Boolean.valueOf(temp.replace("Finish: ", "")));
                            }
                            if (note.getNoteExpired()) {
                                if (temp.startsWith("End: ")) {
                                    note.setNoteEnd(temp.replace("End: ", ""));
                                }
                            }
                        }
                        if (note.getNoteExpired()) {
                            note.setNoteExpiredIcon("\u2714");
                            long millis_start = sdf.parse(note.getNoteStart()).getTime();
                            long millis_end = sdf.parse(note.getNoteEnd()).getTime();

                            long diff = millis_end - millis_start;
                            if (note.getNoteFinish()) {
                                note.setNoteStatus("\u2714"); //เสร็จเเล้ว เเละมีวันหมดอายุ
                                Main.Count_NotEnd++;
                            } else {
                                if (diff > 0) {
                                    note.setNoteStatus("\u263a"); //กำลังดำเนินการ มีวันหมดอายุ
                                    Main.Count_Progress++;
                                } else {
                                    note.setNoteStatus("\u2716"); //ครบกำหนดเเล้ว มีวันหมดอายุ
                                    Main.Count_End++;
                                }
                            }

                        } else {

                            note.setNoteExpiredIcon("\u2716");

                            if (note.getNoteFinish()) {
                                note.setNoteStatus("\u2714"); //เสร็จเเล้ว เเละไม่มีวันหมดอายุ
                                Main.Count_NotEnd++;
                            } else {
                                note.setNoteStatus("\u263a"); //กำลังดำเนินการ //เเต่ไม่มีวันหมดอายุ
                                Main.Count_Progress++;
                            }
                        }

                        MyNoteSystem.Note.add(note);
                        //fr.close();
                        br.close();

                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }

            }
        } catch (java.lang.NullPointerException e) {
            JOptionPane.showMessageDialog(null, getMsg("ไม่พบกิจกรรมในระบบ กรุณาไปเพิ่มก่อน"), "เเจ้งเตือน", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (MyNoteSystem.Note.size() == 0) {
            JOptionPane.showMessageDialog(null, getMsg("ไม่พบกิจกรรมในระบบ กรุณาไปเพิ่มก่อน"), "เเจ้งเตือน", JOptionPane.WARNING_MESSAGE);
            return;
        }

        System.out.println("---- Data ----");
        System.out.println("List: " + MyNoteSystem.Note.size());
        System.out.println("--------------");

        for (MyNote note : MyNoteSystem.Note) {
            System.out.println("Title: " + note.getNoteName());
            System.out.println("Description: " + note.getNoteDescription());
            System.out.println("Expired: " + note.getNoteStatus());
            System.out.println("Start: " + note.getNoteStart());
            if (note.getNoteExpired()) {
                System.out.println("End: " + note.getNoteEnd());
            }
            System.out.println("--------------");
        }

        if (type.equals("DataMenu")) {
            DataListMenu DataMenu = new DataListMenu();
            DataMenu.setLocationRelativeTo(null);
            this.setVisible(false);

            DefaultTableModel model = (DefaultTableModel) DataListMenu.DataTable.getModel();
            MyNote[] mNote = new MyNote[MyNoteSystem.Note.size()];
            for (int i = 0; i < MyNoteSystem.Note.size(); i++) {
                mNote[i] = MyNoteSystem.Note.get(i);
                model.addRow(new Object[]{i, mNote[i].getNoteStatus(), mNote[i].getNoteName(), mNote[i].getNoteDescription(), mNote[i].getNoteExpiredIcon(),
                    mNote[i].getNoteStart(), mNote[i].getNoteEnd()});
            }
            String fName = "/fonts/THSarabunNew.ttf";
            InputStream is = Main.class.getResourceAsStream(fName);
            try {
                //System.out.println(DataListMenu.DataTable.getTableHeader().getFont());
                Font font = Font.createFont(Font.TRUETYPE_FONT, is).deriveFont(Font.PLAIN, 20);
                DataListMenu.DataTable.getTableHeader().setFont(font);
                //System.out.println(DataListMenu.DataTable.getTableHeader().getFont());
            } catch (FontFormatException ex) {
                ex.printStackTrace();
            } catch (IOException ex) {
                ex.printStackTrace();
            }

        } else if (type.equals("ManageMenu")) {
            NoteManageMenu menu = new NoteManageMenu();
            menu.setLocationRelativeTo(null);
            this.setVisible(false);
            MyRenderer renderer = new MyRenderer();
            ImageIcon icon = new ImageIcon(getClass().getResource("/icon/Deleted.png"));
            DefaultTableModel model = (DefaultTableModel) NoteManageMenu.ManageUI.getModel();
            MyNote[] mNote = new MyNote[MyNoteSystem.Note.size()];
            for (int i = 0; i < MyNoteSystem.Note.size(); i++) {
                mNote[i] = MyNoteSystem.Note.get(i);
                renderer.getTableCellRendererComponent(NoteManageMenu.ManageUI, icon);
                NoteManageMenu.ManageUI.getColumnModel().getColumn(3).setCellRenderer(renderer);
                model.addRow(new Object[]{i, mNote[i].getNoteName(), mNote[i].getNoteFinish()});
            }
            String fName = "/fonts/THSarabunNew.ttf";
            InputStream is = Main.class.getResourceAsStream(fName);
            try {
                Font font = Font.createFont(Font.TRUETYPE_FONT, is).deriveFont(Font.PLAIN, 20);
                NoteManageMenu.ManageUI.getTableHeader().setFont(font);
            } catch (FontFormatException ex) {
                ex.printStackTrace();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            NoteManageMenu.ManageUI.setCellSelectionEnabled(false);
            NoteManageMenu.ManageUI.setFocusable(false);
        }
    }

    private JLabel getMsg(String msg) {
        JLabel label = new JLabel(msg);
        label.setFont(new java.awt.Font("TH SarabunPSK", Font.BOLD, 18));

        return label;
    }

    public static JLabel getLabel() {
        return Repeat;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddButton1;
    private javax.swing.JButton Dev_Button;
    private javax.swing.JButton Manage_Button;
    public static javax.swing.JLabel Repeat;
    private javax.swing.JButton SeeButton;
    private javax.swing.Box.Filler filler1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
